---------------------------------
A simple To Do List 
---------------------------------

npm install .

npm start